<?php
include_once 'connection.php';
require_admin();

$msg = flash_msg();
$msgType = flash_type();
$maxMb = (int) (excel_max_upload_bytes() / (1024 * 1024));

$history = [];
$sql = "SELECT li.*, u.name AS uploaded_by_name, u.username AS uploaded_by_username
        FROM lead_imports li
        LEFT JOIN users u ON u.id = li.imported_by
        ORDER BY li.created_at DESC
        LIMIT 100";
$res = $conn->query($sql);
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $history[] = $row;
    }
}

function import_status_badge(string $status): string
{
    $map = [
        'pending' => 'warning',
        'processing' => 'info',
        'completed' => 'success',
        'failed' => 'danger',
        'cancelled' => 'secondary',
    ];
    $cls = $map[$status] ?? 'secondary';
    return '<span class="badge badge-' . $cls . '">' . htmlspecialchars(ucfirst($status)) . '</span>';
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Excel Import | Calling CRM</title>
  <?php include 'includes/header-links.php'; ?>
  <style>
    .upload-drop { padding: 32px 20px; text-align: center; }
    #uploadProgressWrap { display: none; }
    #uploadAlert { display: none; }
    .remarks-cell { max-width: 280px; white-space: normal; font-size: 13px; }
  </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
  <?php include 'includes/top-header.php'; ?>
  <?php include 'includes/sidebar.php'; ?>
  <div class="content-wrapper">
    <?php include 'includes/page-header.php'; ?>
    <section class="content">
      <div class="container-fluid">

        <?php if ($msg): ?>
          <div class="alert alert-<?= htmlspecialchars($msgType === 'error' ? 'danger' : $msgType) ?>">
            <?= htmlspecialchars($msg) ?>
          </div>
        <?php endif; ?>

        <div id="uploadAlert" class="alert" role="alert"></div>

        <div class="card card-outline card-primary">
          <div class="card-header">
            <h3 class="card-title mb-0"><i class="fas fa-file-excel mr-2"></i>Upload &amp; Import Excel</h3>
          </div>
          <div class="card-body">
            <p class="text-muted mb-3">
              Upload <strong>.xls</strong> or <strong>.xlsx</strong> (max <?= $maxMb ?> MB).
              Columns are detected automatically and leads are imported after upload.
              Unknown columns are stored in extra data. Duplicates are skipped by phone or business name.
            </p>

            <form id="excelUploadForm" enctype="multipart/form-data" method="post" action="sql/excel_upload.php">
              <input type="hidden" name="upload_excel" value="1">
              <div class="upload-drop mb-3" id="uploadDrop">
                <i class="fas fa-cloud-upload-alt fa-2x text-muted mb-2"></i>
                <p class="mb-2">Drag &amp; drop your Excel file here, or choose a file</p>
                <input type="file" name="excel_file" id="excel_file" class="form-control-file d-inline-block"
                       accept=".xls,.xlsx,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                       required>
              </div>

              <div id="uploadProgressWrap" class="mb-3">
                <div class="d-flex justify-content-between mb-1">
                  <small class="text-muted">Upload / import progress</small>
                  <small id="uploadProgressPct">0%</small>
                </div>
                <div class="progress" style="height: 18px;">
                  <div id="uploadProgressBar" class="progress-bar bg-primary progress-bar-striped progress-bar-animated"
                       role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
                </div>
              </div>

              <button type="submit" id="uploadBtn" class="btn btn-primary">
                <i class="fas fa-upload mr-1"></i> Upload &amp; Import
              </button>
            </form>
          </div>
        </div>

        <div class="card">
          <div class="card-header">
            <h3 class="card-title mb-0"><i class="fas fa-history mr-2"></i>Upload History</h3>
          </div>
          <div class="card-body table-responsive p-0">
            <table class="table table-hover table-striped mb-0" id="uploadHistoryTable">
              <thead>
                <tr>
                  <th>#</th>
                  <th>File Name</th>
                  <th>Uploaded By</th>
                  <th>Upload Date</th>
                  <th>Total</th>
                  <th>Imported</th>
                  <th>Duplicates</th>
                  <th>Failed</th>
                  <th>Status</th>
                  <th>Remarks</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php if (!$history): ?>
                  <tr id="historyEmptyRow">
                    <td colspan="11" class="text-center text-muted py-4">No uploads yet.</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($history as $row): ?>
                    <?php
                      $canProcess = in_array($row['status'], ['pending', 'failed'], true)
                          && !empty($row['stored_filename']);
                    ?>
                    <tr data-import-id="<?= (int) $row['id'] ?>">
                      <td><?= (int) $row['id'] ?></td>
                      <td><?= htmlspecialchars($row['original_filename'] ?: $row['filename']) ?></td>
                      <td><?= htmlspecialchars($row['uploaded_by_name'] ?: ($row['uploaded_by_username'] ?: '—')) ?></td>
                      <td><?= htmlspecialchars($row['created_at']) ?></td>
                      <td class="col-total"><?= (int) $row['total_rows'] ?></td>
                      <td class="col-success"><?= (int) $row['success_count'] ?></td>
                      <td class="col-dup"><?= (int) $row['duplicate_count'] ?></td>
                      <td class="col-failed"><?= (int) $row['failed_count'] ?></td>
                      <td class="col-status"><?= import_status_badge($row['status']) ?></td>
                      <td class="remarks-cell col-remarks"><?= htmlspecialchars($row['remarks'] ?: ($row['notes'] ?: '—')) ?></td>
                      <td class="col-action">
                        <?php if ((int) $row['success_count'] > 0 || $row['status'] === 'completed'): ?>
                          <a href="leads.php?import_id=<?= (int) $row['id'] ?>" class="btn btn-sm btn-success mb-1"
                             title="View leads from this Excel file">
                            <i class="fas fa-address-book"></i> View Leads
                          </a>
                        <?php endif; ?>
                        <?php if ($canProcess): ?>
                          <button type="button" class="btn btn-sm btn-outline-primary btn-process-import"
                                  data-id="<?= (int) $row['id'] ?>">
                            <i class="fas fa-database"></i> Import Leads
                          </button>
                        <?php elseif ((int) $row['success_count'] <= 0 && $row['status'] !== 'completed'): ?>
                          <span class="text-muted">—</span>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </section>
  </div>
  <?php include 'includes/copyright.php'; ?>
</div>
<?php include 'includes/footer-links.php'; ?>
<script>
(function ($) {
  var $form = $('#excelUploadForm');
  var $file = $('#excel_file');
  var $btn = $('#uploadBtn');
  var $wrap = $('#uploadProgressWrap');
  var $bar = $('#uploadProgressBar');
  var $pct = $('#uploadProgressPct');
  var $alert = $('#uploadAlert');
  var $drop = $('#uploadDrop');
  var maxBytes = <?= (int) excel_max_upload_bytes() ?>;
  var allowed = ['xls', 'xlsx'];

  function showAlert(type, message) {
    $alert
      .removeClass('alert-success alert-danger alert-warning alert-info')
      .addClass('alert-' + type)
      .html($('<div>').text(message).html())
      .show();
    $('html, body').animate({ scrollTop: 0 }, 200);
  }

  function setProgress(p) {
    p = Math.max(0, Math.min(100, Math.round(p)));
    $bar.css('width', p + '%').attr('aria-valuenow', p).text(p + '%');
    $pct.text(p + '%');
  }

  function statusBadge(status) {
    var map = { pending: 'warning', processing: 'info', completed: 'success', failed: 'danger', cancelled: 'secondary' };
    var cls = map[status] || 'secondary';
    var label = status ? status.charAt(0).toUpperCase() + status.slice(1) : '';
    return '<span class="badge badge-' + cls + '">' + label + '</span>';
  }

  function esc(s) {
    return $('<div>').text(s == null ? '' : String(s)).html();
  }

  function prependHistoryRow(data) {
    $('#historyEmptyRow').remove();
    var status = data.status || 'pending';
    var status = data.status || 'pending';
    var canProcess = (status === 'pending' || status === 'failed');
    var successCount = data.success_count != null ? data.success_count : 0;
    var action = '';
    if (successCount > 0 || status === 'completed') {
      action += '<a href="leads.php?import_id=' + (data.id || '') + '" class="btn btn-sm btn-success mb-1"><i class="fas fa-address-book"></i> View Leads</a> ';
    }
    if (canProcess) {
      action += '<button type="button" class="btn btn-sm btn-outline-primary btn-process-import" data-id="' + (data.id || '') + '"><i class="fas fa-database"></i> Import Leads</button>';
    }
    if (!action) {
      action = '<span class="text-muted">—</span>';
    }
    var row = '<tr data-import-id="' + (data.id || '') + '">' +
      '<td>' + (data.id || '') + '</td>' +
      '<td>' + esc(data.file_name) + '</td>' +
      '<td>' + esc(data.uploaded_by) + '</td>' +
      '<td>' + esc(data.upload_date) + '</td>' +
      '<td class="col-total">' + (data.total_records != null ? data.total_records : 0) + '</td>' +
      '<td class="col-success">' + successCount + '</td>' +
      '<td class="col-dup">' + (data.duplicate_count != null ? data.duplicate_count : 0) + '</td>' +
      '<td class="col-failed">' + (data.failed_count != null ? data.failed_count : 0) + '</td>' +
      '<td class="col-status">' + statusBadge(status) + '</td>' +
      '<td class="remarks-cell col-remarks">' + esc(data.remarks) + '</td>' +
      '<td class="col-action">' + action + '</td>' +
      '</tr>';
    $('#uploadHistoryTable tbody').prepend(row);
  }

  function updateHistoryRow(id, data) {
    var $tr = $('tr[data-import-id="' + id + '"]');
    if (!$tr.length) return;
    $tr.find('.col-total').text(data.total != null ? data.total : 0);
    $tr.find('.col-success').text(data.success_count != null ? data.success_count : 0);
    $tr.find('.col-dup').text(data.duplicate_count != null ? data.duplicate_count : 0);
    $tr.find('.col-failed').text(data.failed_count != null ? data.failed_count : 0);
    $tr.find('.col-status').html(statusBadge(data.status || 'pending'));
    $tr.find('.col-remarks').text(data.message || data.remarks || '');
    var status = data.status || 'pending';
    var successCount = data.success_count != null ? data.success_count : 0;
    var action = '';
    if (successCount > 0 || status === 'completed') {
      action += '<a href="leads.php?import_id=' + id + '" class="btn btn-sm btn-success mb-1"><i class="fas fa-address-book"></i> View Leads</a> ';
    }
    if (status === 'pending' || status === 'failed') {
      action += '<button type="button" class="btn btn-sm btn-outline-primary btn-process-import" data-id="' + id + '"><i class="fas fa-database"></i> Import Leads</button>';
    }
    if (!action) {
      action = '<span class="text-muted">—</span>';
    }
    $tr.find('.col-action').html(action);
  }

  function validateClient() {
    var input = $file[0];
    if (!input.files || !input.files.length) {
      showAlert('danger', 'Please choose an Excel file (.xls or .xlsx).');
      return false;
    }
    var f = input.files[0];
    var ext = (f.name.split('.').pop() || '').toLowerCase();
    if (allowed.indexOf(ext) === -1) {
      showAlert('danger', 'Invalid file type. Only .xls and .xlsx files are allowed.');
      return false;
    }
    if (f.size <= 0) {
      showAlert('danger', 'The selected file is empty.');
      return false;
    }
    if (f.size > maxBytes) {
      showAlert('danger', 'File size exceeds the <?= $maxMb ?> MB limit.');
      return false;
    }
    return true;
  }

  $drop.on('dragover dragenter', function (e) {
    e.preventDefault();
    e.stopPropagation();
    $drop.addClass('dragover');
  }).on('dragleave drop', function (e) {
    e.preventDefault();
    e.stopPropagation();
    $drop.removeClass('dragover');
    if (e.type === 'drop' && e.originalEvent.dataTransfer && e.originalEvent.dataTransfer.files.length) {
      $file[0].files = e.originalEvent.dataTransfer.files;
    }
  });

  $form.on('submit', function (e) {
    e.preventDefault();
    $alert.hide();
    if (!validateClient()) return;

    var fd = new FormData($form[0]);
    $btn.prop('disabled', true);
    $wrap.show();
    setProgress(0);

    $.ajax({
      url: 'sql/excel_upload.php',
      method: 'POST',
      data: fd,
      processData: false,
      contentType: false,
      dataType: 'json',
      xhr: function () {
        var xhr = $.ajaxSettings.xhr();
        if (xhr.upload) {
          xhr.upload.addEventListener('progress', function (ev) {
            if (ev.lengthComputable) {
              // Upload is first half; leave room for server-side import feel
              setProgress((ev.loaded / ev.total) * 90);
            }
          });
        }
        return xhr;
      },
      success: function (res) {
        setProgress(100);
        if (res && res.data) prependHistoryRow(res.data);
        if (res && res.success) {
          showAlert('success', res.message || 'Upload & import successful.');
          $form[0].reset();
        } else {
          showAlert('warning', (res && res.message) ? res.message : 'Import finished with issues.');
        }
      },
      error: function (xhr) {
        var msg = 'Upload failed. Please try again.';
        var res = null;
        try { res = JSON.parse(xhr.responseText); } catch (err) {}
        if (res && res.message) msg = res.message;
        if (res && res.data) prependHistoryRow(res.data);
        showAlert('danger', msg);
      },
      complete: function () {
        $btn.prop('disabled', false);
        setTimeout(function () { $wrap.fadeOut(200); }, 800);
      }
    });
  });

  $(document).on('click', '.btn-process-import', function () {
    var id = $(this).data('id');
    var $button = $(this);
    if (!id) return;
    $button.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i>');
    $.ajax({
      url: 'sql/process_excel_import.php',
      method: 'POST',
      data: { import_id: id },
      dataType: 'json',
      success: function (res) {
        if (res) updateHistoryRow(id, res);
        showAlert(res && res.success ? 'success' : 'warning', (res && res.message) ? res.message : 'Done.');
      },
      error: function (xhr) {
        var msg = 'Import failed.';
        try {
          var res = JSON.parse(xhr.responseText);
          if (res && res.message) msg = res.message;
          if (res) updateHistoryRow(id, res);
        } catch (err) {}
        showAlert('danger', msg);
        $button.prop('disabled', false).html('<i class="fas fa-database"></i> Import Leads');
      },
      complete: function () {
        // button state updated in success via updateHistoryRow
      }
    });
  });
})(jQuery);
</script>
</body>
</html>
