<?php
$userName = $_SESSION['name'] ?? 'Admin';
$initial = strtoupper(mb_substr(trim($userName), 0, 1));
?>
<nav class="main-header navbar navbar-expand">
  <ul class="navbar-nav align-items-center">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
      </a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <a href="dashboard.php" class="nav-link crm-brand-link">Calling CRM</a>
    </li>
  </ul>
  <ul class="navbar-nav ml-auto align-items-center pr-3">
    <li class="nav-item">
      <span class="crm-user-chip">
        <span class="crm-user-avatar"><?= htmlspecialchars($initial) ?></span>
        <?= htmlspecialchars($userName) ?>
      </span>
    </li>
  </ul>
</nav>
