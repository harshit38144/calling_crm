<?php
include_once 'connection.php';
require_admin();

$msg = flash_msg();
$msgType = flash_type();
$statuses = lead_statuses();

$categories = [];
$cities = [];
$executives = [];
$imports = [];

$preselectedImportId = (int) ($_GET['import_id'] ?? 0);

$res = $conn->query("SELECT DISTINCT category FROM leads WHERE is_deleted = 0 AND category <> '' ORDER BY category");
while ($row = $res->fetch_assoc()) {
    $categories[] = $row['category'];
}
$res = $conn->query("SELECT DISTINCT city FROM leads WHERE is_deleted = 0 AND city <> '' ORDER BY city");
while ($row = $res->fetch_assoc()) {
    $cities[] = $row['city'];
}
$res = $conn->query("SELECT id, name, username FROM users WHERE status = 'active' ORDER BY name");
while ($row = $res->fetch_assoc()) {
    $executives[] = $row;
}
$res = $conn->query(
    "SELECT li.id, li.original_filename, li.filename, li.created_at, li.success_count, li.status,
            (SELECT COUNT(*) FROM leads l WHERE l.import_id = li.id AND l.is_deleted = 0) AS lead_count
     FROM lead_imports li
     ORDER BY li.created_at DESC"
);
while ($row = $res->fetch_assoc()) {
    $imports[] = $row;
}

$activeImportLabel = '';
if ($preselectedImportId > 0) {
    foreach ($imports as $imp) {
        if ((int) $imp['id'] === $preselectedImportId) {
            $activeImportLabel = $imp['original_filename'] ?: $imp['filename'];
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Leads | Calling CRM</title>
  <?php include 'includes/header-links.php'; ?>
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <style>
    .filter-bar .form-control, .filter-bar .custom-select { height: calc(1.8125rem + 2px); font-size: 0.9rem; }
    .bulk-bar { display: none; }
    #leadsTable td { vertical-align: middle; }
    .import-file-chip { font-size: 12px; }
  </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
  <?php include 'includes/top-header.php'; ?>
  <?php include 'includes/sidebar.php'; ?>
  <div class="content-wrapper">
    <?php include 'includes/page-header.php'; ?>
    <section class="content">
      <div class="container-fluid">

        <?php if ($msg): ?>
          <div class="alert alert-<?= htmlspecialchars($msgType === 'error' ? 'danger' : $msgType) ?>">
            <?= htmlspecialchars($msg) ?>
          </div>
        <?php endif; ?>
        <div id="leadsAlert" class="alert" style="display:none;"></div>

        <?php if ($activeImportLabel !== ''): ?>
          <div class="alert alert-info py-2">
            Showing leads from Excel file:
            <strong><?= htmlspecialchars($activeImportLabel) ?></strong>
            <a href="leads.php" class="float-right">Clear file filter</a>
          </div>
        <?php endif; ?>

        <div class="card card-outline card-primary">
          <div class="card-header d-flex align-items-center">
            <h3 class="card-title mb-0"><i class="fas fa-address-book mr-2"></i>Lead List</h3>
            <div class="card-tools ml-auto">
              <a href="import_excel.php" class="btn btn-sm btn-outline-primary mr-1"><i class="fas fa-file-excel"></i> Imports</a>
              <a href="lead_edit.php" class="btn btn-sm btn-success"><i class="fas fa-plus"></i> Add Lead</a>
            </div>
          </div>
          <div class="card-body">
            <div class="row filter-bar mb-3">
              <div class="col-md-3 mb-2">
                <select id="filter_import" class="custom-select">
                  <option value="">All Excel Files</option>
                  <option value="manual" <?= $preselectedImportId === 0 && isset($_GET['import_id']) && $_GET['import_id'] === 'manual' ? 'selected' : '' ?>>Manual / No File</option>
                  <?php foreach ($imports as $imp): ?>
                    <?php
                      $label = ($imp['original_filename'] ?: $imp['filename']) ?: ('Import #' . $imp['id']);
                      $label .= ' (' . (int) $imp['lead_count'] . ' leads · ' . $imp['created_at'] . ')';
                    ?>
                    <option value="<?= (int) $imp['id'] ?>" <?= $preselectedImportId === (int) $imp['id'] ? 'selected' : '' ?>>
                      <?= htmlspecialchars($label) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-2 mb-2">
                <select id="filter_status" class="custom-select">
                  <option value="">All Status</option>
                  <?php foreach ($statuses as $k => $label): ?>
                    <option value="<?= htmlspecialchars($k) ?>"><?= htmlspecialchars($label) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-2 mb-2">
                <select id="filter_category" class="custom-select">
                  <option value="">All Categories</option>
                  <?php foreach ($categories as $c): ?>
                    <option value="<?= htmlspecialchars($c) ?>"><?= htmlspecialchars($c) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-2 mb-2">
                <select id="filter_city" class="custom-select">
                  <option value="">All Cities</option>
                  <?php foreach ($cities as $c): ?>
                    <option value="<?= htmlspecialchars($c) ?>"><?= htmlspecialchars($c) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-2 mb-2">
                <select id="filter_executive" class="custom-select">
                  <option value="">All Executives</option>
                  <option value="unassigned">Unassigned</option>
                  <?php foreach ($executives as $e): ?>
                    <option value="<?= (int) $e['id'] ?>"><?= htmlspecialchars($e['name'] ?: $e['username']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-3 mb-2">
                <input type="text" id="global_search" class="form-control" placeholder="Search business, phone, email, address…">
              </div>
              <div class="col-md-1 mb-2">
                <button type="button" id="btnResetFilters" class="btn btn-outline-secondary btn-block" title="Reset">
                  <i class="fas fa-undo"></i>
                </button>
              </div>
            </div>

            <div class="bulk-bar alert alert-light border mb-3 py-2">
              <div class="form-inline flex-wrap">
                <span class="mr-3"><strong id="selectedCount">0</strong> selected</span>
                <select id="bulk_status" class="custom-select custom-select-sm mr-2 mb-1" style="width:auto;">
                  <option value="">Set Status…</option>
                  <?php foreach ($statuses as $k => $label): ?>
                    <option value="<?= htmlspecialchars($k) ?>"><?= htmlspecialchars($label) ?></option>
                  <?php endforeach; ?>
                </select>
                <button type="button" id="btnBulkStatus" class="btn btn-sm btn-primary mr-2 mb-1">Apply Status</button>
                <select id="bulk_assign" class="custom-select custom-select-sm mr-2 mb-1" style="width:auto;">
                  <option value="">Assign To…</option>
                  <option value="0">Unassign</option>
                  <?php foreach ($executives as $e): ?>
                    <option value="<?= (int) $e['id'] ?>"><?= htmlspecialchars($e['name'] ?: $e['username']) ?></option>
                  <?php endforeach; ?>
                </select>
                <button type="button" id="btnBulkAssign" class="btn btn-sm btn-info mr-2 mb-1">Assign</button>
                <button type="button" id="btnBulkDelete" class="btn btn-sm btn-danger mb-1">Delete Selected</button>
              </div>
            </div>

            <table id="leadsTable" class="table table-bordered table-striped table-hover" style="width:100%">
              <thead>
                <tr>
                  <th width="30"><input type="checkbox" id="checkAll"></th>
                  <th>ID</th>
                  <th>Business</th>
                  <th>Phone</th>
                  <th>Email</th>
                  <th>City</th>
                  <th>Category</th>
                  <th>Status</th>
                  <th>Excel File</th>
                  <th>Executive</th>
                  <th>Created</th>
                  <th width="140">Actions</th>
                </tr>
              </thead>
            </table>
          </div>
        </div>

      </div>
    </section>
  </div>
  <?php include 'includes/copyright.php'; ?>
</div>
<?php include 'includes/footer-links.php'; ?>
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script>
(function ($) {
  function showAlert(type, msg) {
    $('#leadsAlert').removeClass('alert-success alert-danger alert-warning')
      .addClass('alert-' + type).text(msg).show();
  }

  function selectedIds() {
    return $('.lead-check:checked').map(function () { return $(this).val(); }).get();
  }

  function updateBulkBar() {
    var n = selectedIds().length;
    $('#selectedCount').text(n);
    $('.bulk-bar').toggle(n > 0);
    $('#checkAll').prop('checked', n > 0 && n === $('.lead-check').length);
  }

  function syncImportUrl() {
    var importId = $('#filter_import').val();
    var url = new URL(window.location.href);
    if (importId) {
      url.searchParams.set('import_id', importId);
    } else {
      url.searchParams.delete('import_id');
    }
    window.history.replaceState({}, '', url.pathname + url.search);
  }

  var table = $('#leadsTable').DataTable({
    processing: true,
    serverSide: true,
    responsive: true,
    pageLength: 25,
    order: [[1, 'desc']],
    ajax: {
      url: 'sql/leads_datatable.php',
      type: 'POST',
      data: function (d) {
        d.filter_import = $('#filter_import').val();
        d.filter_status = $('#filter_status').val();
        d.filter_category = $('#filter_category').val();
        d.filter_city = $('#filter_city').val();
        d.filter_executive = $('#filter_executive').val();
        d.global_search = $('#global_search').val();
        d.search = { value: $('#global_search').val() };
      }
    },
    columns: [
      { data: 'checkbox', orderable: false, searchable: false },
      { data: 'id' },
      { data: 'business_name' },
      { data: 'phone' },
      { data: 'email' },
      { data: 'city' },
      { data: 'category' },
      { data: 'status', orderable: true },
      { data: 'excel_file', orderable: true },
      { data: 'executive' },
      { data: 'created_at' },
      { data: 'actions', orderable: false, searchable: false }
    ],
    drawCallback: function () {
      updateBulkBar();
    }
  });

  var searchTimer = null;
  $('#global_search').on('keyup', function () {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(function () { table.ajax.reload(); }, 350);
  });
  $('#filter_import, #filter_status, #filter_category, #filter_city, #filter_executive').on('change', function () {
    if (this.id === 'filter_import') {
      syncImportUrl();
    }
    table.ajax.reload();
  });
  $('#btnResetFilters').on('click', function () {
    $('#filter_import, #filter_status, #filter_category, #filter_city, #filter_executive, #global_search').val('');
    syncImportUrl();
    table.ajax.reload();
  });

  $('#checkAll').on('change', function () {
    $('.lead-check').prop('checked', this.checked);
    updateBulkBar();
  });
  $(document).on('change', '.lead-check', updateBulkBar);

  function postAction(data, okMsg) {
    return $.ajax({
      url: 'sql/leads_actions.php',
      method: 'POST',
      data: $.extend({ ajax: 1 }, data),
      dataType: 'json',
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    }).done(function (res) {
      showAlert(res.success ? 'success' : 'danger', res.message || okMsg);
      if (res.success) {
        table.ajax.reload(null, false);
        $('#checkAll').prop('checked', false);
        updateBulkBar();
      }
    }).fail(function (xhr) {
      var msg = 'Action failed.';
      try { msg = JSON.parse(xhr.responseText).message || msg; } catch (e) {}
      showAlert('danger', msg);
    });
  }

  $(document).on('click', '.btn-delete-lead', function () {
    var id = $(this).data('id');
    if (!confirm('Delete this lead?')) return;
    postAction({ action: 'delete', id: id });
  });

  $('#btnBulkDelete').on('click', function () {
    var ids = selectedIds();
    if (!ids.length || !confirm('Delete ' + ids.length + ' selected lead(s)?')) return;
    postAction({ action: 'bulk_delete', ids: ids });
  });

  $('#btnBulkStatus').on('click', function () {
    var ids = selectedIds();
    var status = $('#bulk_status').val();
    if (!ids.length) return;
    if (!status) { showAlert('warning', 'Choose a status.'); return; }
    postAction({ action: 'bulk_status', ids: ids, status: status });
  });

  $('#btnBulkAssign').on('click', function () {
    var ids = selectedIds();
    var assigned = $('#bulk_assign').val();
    if (!ids.length) return;
    if (assigned === '') { showAlert('warning', 'Choose an executive.'); return; }
    postAction({ action: 'bulk_assign', ids: ids, assigned_to: assigned });
  });
})(jQuery);
</script>
</body>
</html>
