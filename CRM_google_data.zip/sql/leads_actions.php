<?php
/**
 * Lead CRUD / bulk action handler (AJAX + form POST).
 */
include_once __DIR__ . '/../connection.php';

if (empty($_SESSION['id'])) {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        json_response(['success' => false, 'message' => 'Unauthorized'], 401);
    }
    header('Location: ../index.php');
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
    || (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
    || !empty($_POST['ajax']);

function redirect_back(string $fallback = '../leads.php'): void
{
    $ref = $_SERVER['HTTP_REFERER'] ?? $fallback;
    header('Location: ' . $ref);
    exit;
}

function parse_ids($raw): array
{
    if (is_array($raw)) {
        return array_values(array_unique(array_filter(array_map('intval', $raw))));
    }
    if (is_string($raw) && $raw !== '') {
        return array_values(array_unique(array_filter(array_map('intval', explode(',', $raw)))));
    }
    return [];
}

function log_status_history(mysqli $conn, int $leadId, string $old, string $new, int $userId, string $notes = ''): void
{
    if ($old === $new) {
        return;
    }
    $stmt = $conn->prepare(
        'INSERT INTO lead_status_history (lead_id, changed_by, old_status, new_status, notes)
         VALUES (?, ?, ?, ?, ?)'
    );
    $stmt->bind_param('iisss', $leadId, $userId, $old, $new, $notes);
    $stmt->execute();
}

$userId = (int) $_SESSION['id'];

/* ---------- Soft delete single ---------- */
if ($action === 'delete') {
    $id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
    if ($id <= 0) {
        if ($isAjax) {
            json_response(['success' => false, 'message' => 'Invalid lead id.'], 400);
        }
        set_flash('Invalid lead id.', 'error');
        redirect_back();
    }
    $conn->query("UPDATE leads SET is_deleted = 1 WHERE id = {$id}");
    if ($isAjax) {
        json_response(['success' => true, 'message' => 'Lead deleted.']);
    }
    set_flash('Lead deleted successfully.');
    redirect_back();
}

/* ---------- Bulk delete ---------- */
if ($action === 'bulk_delete') {
    $ids = parse_ids($_POST['ids'] ?? []);
    if (!$ids) {
        json_response(['success' => false, 'message' => 'No leads selected.'], 400);
    }
    $idList = implode(',', $ids);
    $conn->query("UPDATE leads SET is_deleted = 1 WHERE id IN ({$idList}) AND is_deleted = 0");
    $affected = $conn->affected_rows;
    json_response(['success' => true, 'message' => "Deleted {$affected} lead(s).", 'count' => $affected]);
}

/* ---------- Bulk status ---------- */
if ($action === 'bulk_status') {
    $ids = parse_ids($_POST['ids'] ?? []);
    $status = trim((string) ($_POST['status'] ?? ''));
    if (!$ids) {
        json_response(['success' => false, 'message' => 'No leads selected.'], 400);
    }
    if (!array_key_exists($status, lead_statuses())) {
        json_response(['success' => false, 'message' => 'Invalid status.'], 400);
    }
    $idList = implode(',', $ids);
    $res = $conn->query("SELECT id, status FROM leads WHERE id IN ({$idList}) AND is_deleted = 0");
    while ($row = $res->fetch_assoc()) {
        log_status_history($conn, (int) $row['id'], $row['status'], $status, $userId, 'Bulk status update');
    }
    $st = $conn->real_escape_string($status);
    $conn->query("UPDATE leads SET status = '{$st}' WHERE id IN ({$idList}) AND is_deleted = 0");
    json_response(['success' => true, 'message' => 'Status updated for selected leads.', 'count' => $conn->affected_rows]);
}

/* ---------- Bulk assign ---------- */
if ($action === 'bulk_assign') {
    $ids = parse_ids($_POST['ids'] ?? []);
    $executive = (int) ($_POST['assigned_to'] ?? 0);
    if (!$ids) {
        json_response(['success' => false, 'message' => 'No leads selected.'], 400);
    }

    $idList = implode(',', $ids);
    if ($executive <= 0) {
        $conn->query("UPDATE leads SET assigned_to = NULL WHERE id IN ({$idList}) AND is_deleted = 0");
        // Deactivate active assignments
        $conn->query(
            "UPDATE lead_assignments SET is_active = 0, unassigned_at = NOW()
             WHERE lead_id IN ({$idList}) AND is_active = 1"
        );
        json_response(['success' => true, 'message' => 'Leads unassigned.', 'count' => count($ids)]);
    }

    $u = $conn->query("SELECT id FROM users WHERE id = {$executive} AND status = 'active' LIMIT 1");
    if (!$u || !$u->fetch_assoc()) {
        json_response(['success' => false, 'message' => 'Invalid executive.'], 400);
    }

    $conn->query(
        "UPDATE lead_assignments SET is_active = 0, unassigned_at = NOW()
         WHERE lead_id IN ({$idList}) AND is_active = 1"
    );

    foreach ($ids as $leadId) {
        $conn->query("UPDATE leads SET assigned_to = {$executive}, status = IF(status = 'new', 'not_contacted', status)
                      WHERE id = {$leadId} AND is_deleted = 0");
        $stmt = $conn->prepare(
            'INSERT INTO lead_assignments (lead_id, user_id, assigned_by, is_active)
             VALUES (?, ?, ?, 1)'
        );
        $stmt->bind_param('iii', $leadId, $executive, $userId);
        $stmt->execute();
    }

    json_response(['success' => true, 'message' => 'Leads assigned successfully.', 'count' => count($ids)]);
}

/* ---------- Save lead (create / update) ---------- */
if ($action === 'save') {
    $id = (int) ($_POST['id'] ?? 0);

    $fields = [
        'business_name' => trim((string) ($_POST['business_name'] ?? '')),
        'contact_name' => trim((string) ($_POST['contact_name'] ?? '')),
        'phone' => trim((string) ($_POST['phone'] ?? '')),
        'alternate_phone' => trim((string) ($_POST['alternate_phone'] ?? '')),
        'email' => trim((string) ($_POST['email'] ?? '')),
        'website' => trim((string) ($_POST['website'] ?? '')),
        'category' => trim((string) ($_POST['category'] ?? '')),
        'address' => trim((string) ($_POST['address'] ?? '')),
        'city' => trim((string) ($_POST['city'] ?? '')),
        'state' => trim((string) ($_POST['state'] ?? '')),
        'country' => trim((string) ($_POST['country'] ?? '')),
        'pincode' => trim((string) ($_POST['pincode'] ?? '')),
        'maps_url' => trim((string) ($_POST['maps_url'] ?? '')),
        'notes' => trim((string) ($_POST['notes'] ?? '')),
        'remarks' => trim((string) ($_POST['remarks'] ?? '')),
    ];

    $status = trim((string) ($_POST['status'] ?? 'new'));
    if (!array_key_exists($status, lead_statuses())) {
        $status = 'new';
    }
    $priority = trim((string) ($_POST['priority'] ?? 'medium'));
    if (!array_key_exists($priority, lead_priorities())) {
        $priority = 'medium';
    }

    $assignedTo = (int) ($_POST['assigned_to'] ?? 0);
    $assignedToVal = $assignedTo > 0 ? $assignedTo : null;

    $ratingRaw = trim((string) ($_POST['rating'] ?? ''));
    $rating = ($ratingRaw !== '' && is_numeric($ratingRaw)) ? round((float) $ratingRaw, 2) : null;
    $reviewCount = max(0, (int) ($_POST['review_count'] ?? 0));

    $latRaw = trim((string) ($_POST['latitude'] ?? ''));
    $lngRaw = trim((string) ($_POST['longitude'] ?? ''));
    $lat = ($latRaw !== '' && is_numeric($latRaw)) ? (float) $latRaw : null;
    $lng = ($lngRaw !== '' && is_numeric($lngRaw)) ? (float) $lngRaw : null;

    $nextFollowupRaw = trim((string) ($_POST['next_followup_at'] ?? ''));
    $nextFollowupSql = 'NULL';
    if ($nextFollowupRaw !== '') {
        $fts = strtotime($nextFollowupRaw);
        if ($fts) {
            $nextFollowupSql = "'" . $conn->real_escape_string(date('Y-m-d H:i:s', $fts)) . "'";
        }
    }

    if ($fields['business_name'] === '' && $fields['phone'] === '') {
        set_flash('Business name or phone is required.', 'error');
        header('Location: ' . ($id > 0 ? "../lead_edit.php?id={$id}" : '../lead_edit.php'));
        exit;
    }

    $esc = function ($v) use ($conn) {
        return "'" . $conn->real_escape_string((string) $v) . "'";
    };
    $nullOrFloat = function ($v) {
        return $v === null ? 'NULL' : (string) (float) $v;
    };
    $nullOrInt = function ($v) {
        return $v === null ? 'NULL' : (string) (int) $v;
    };

    if ($id > 0) {
        $existing = $conn->query("SELECT * FROM leads WHERE id = {$id} AND is_deleted = 0")->fetch_assoc();
        if (!$existing) {
            set_flash('Lead not found.', 'error');
            header('Location: ../leads.php');
            exit;
        }

        $sql = "UPDATE leads SET
            business_name = {$esc($fields['business_name'])},
            contact_name = {$esc($fields['contact_name'])},
            phone = {$esc($fields['phone'])},
            alternate_phone = {$esc($fields['alternate_phone'])},
            email = {$esc($fields['email'])},
            website = {$esc($fields['website'])},
            category = {$esc($fields['category'])},
            address = {$esc($fields['address'])},
            city = {$esc($fields['city'])},
            state = {$esc($fields['state'])},
            country = {$esc($fields['country'])},
            pincode = {$esc($fields['pincode'])},
            maps_url = {$esc($fields['maps_url'])},
            notes = {$esc($fields['notes'])},
            remarks = {$esc($fields['remarks'])},
            next_followup_at = {$nextFollowupSql},
            status = {$esc($status)},
            priority = {$esc($priority)},
            assigned_to = {$nullOrInt($assignedToVal)},
            rating = {$nullOrFloat($rating)},
            review_count = {$reviewCount},
            latitude = {$nullOrFloat($lat)},
            longitude = {$nullOrFloat($lng)}
            WHERE id = {$id}";

        if ($conn->query($sql)) {
            log_status_history($conn, $id, $existing['status'], $status, $userId, 'Lead edited');

            // Assignment sync
            $oldAssigned = (int) ($existing['assigned_to'] ?? 0);
            if ($oldAssigned !== (int) ($assignedToVal ?? 0)) {
                $conn->query(
                    "UPDATE lead_assignments SET is_active = 0, unassigned_at = NOW()
                     WHERE lead_id = {$id} AND is_active = 1"
                );
                if ($assignedToVal) {
                    $stmt = $conn->prepare(
                        'INSERT INTO lead_assignments (lead_id, user_id, assigned_by, is_active) VALUES (?, ?, ?, 1)'
                    );
                    $stmt->bind_param('iii', $id, $assignedToVal, $userId);
                    $stmt->execute();
                }
            }

            set_flash('Lead updated successfully.');
            header("Location: ../lead_view.php?id={$id}");
            exit;
        }

        set_flash('Update failed: ' . $conn->error, 'error');
        header("Location: ../lead_edit.php?id={$id}");
        exit;
    }

    // Create
    $source = 'manual';
    $sql = "INSERT INTO leads (
        created_by, assigned_to, business_name, contact_name, phone, alternate_phone,
        email, website, category, address, city, state, country, pincode, maps_url,
        rating, review_count, latitude, longitude, status, priority, notes, source
    ) VALUES (
        {$userId}, {$nullOrInt($assignedToVal)}, {$esc($fields['business_name'])}, {$esc($fields['contact_name'])},
        {$esc($fields['phone'])}, {$esc($fields['alternate_phone'])}, {$esc($fields['email'])},
        {$esc($fields['website'])}, {$esc($fields['category'])}, {$esc($fields['address'])},
        {$esc($fields['city'])}, {$esc($fields['state'])}, {$esc($fields['country'])},
        {$esc($fields['pincode'])}, {$esc($fields['maps_url'])},
        {$nullOrFloat($rating)}, {$reviewCount}, {$nullOrFloat($lat)}, {$nullOrFloat($lng)},
        {$esc($status)}, {$esc($priority)}, {$esc($fields['notes'])}, {$esc($source)}
    )";

    if ($conn->query($sql)) {
        $newId = (int) $conn->insert_id;
        if ($assignedToVal) {
            $stmt = $conn->prepare(
                'INSERT INTO lead_assignments (lead_id, user_id, assigned_by, is_active) VALUES (?, ?, ?, 1)'
            );
            $stmt->bind_param('iii', $newId, $assignedToVal, $userId);
            $stmt->execute();
        }
        log_status_history($conn, $newId, '', $status, $userId, 'Lead created');
        set_flash('Lead created successfully.');
        header("Location: ../lead_view.php?id={$newId}");
        exit;
    }

    set_flash('Create failed: ' . $conn->error, 'error');
    header('Location: ../lead_edit.php');
    exit;
}

if ($isAjax) {
    json_response(['success' => false, 'message' => 'Unknown action.'], 400);
}
set_flash('Unknown action.', 'error');
redirect_back();
