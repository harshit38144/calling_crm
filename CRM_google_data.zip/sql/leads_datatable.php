<?php
/**
 * DataTables server-side endpoint for leads list.
 */
include_once __DIR__ . '/../connection.php';

header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$draw = (int) ($_POST['draw'] ?? 1);
$start = max(0, (int) ($_POST['start'] ?? 0));
$length = (int) ($_POST['length'] ?? 25);
if ($length < 1) {
    $length = 25;
}
if ($length > 200) {
    $length = 200;
}

$search = trim((string) ($_POST['search']['value'] ?? $_POST['global_search'] ?? ''));
$filterStatus = trim((string) ($_POST['filter_status'] ?? ''));
$filterCategory = trim((string) ($_POST['filter_category'] ?? ''));
$filterCity = trim((string) ($_POST['filter_city'] ?? ''));
$filterExecutive = trim((string) ($_POST['filter_executive'] ?? ''));
$filterImport = trim((string) ($_POST['filter_import'] ?? ''));

$columns = [
    0 => 'l.id',
    1 => 'l.id',
    2 => 'l.business_name',
    3 => 'l.phone',
    4 => 'l.email',
    5 => 'l.city',
    6 => 'l.category',
    7 => 'l.status',
    8 => 'li.original_filename',
    9 => 'u.name',
    10 => 'l.created_at',
    11 => 'l.id',
];

$orderCol = (int) ($_POST['order'][0]['column'] ?? 0);
$orderDir = strtolower((string) ($_POST['order'][0]['dir'] ?? 'desc')) === 'asc' ? 'ASC' : 'DESC';
$orderBy = $columns[$orderCol] ?? 'l.id';

$where = ['l.is_deleted = 0'];
$types = '';
$params = [];

if ($filterImport === 'manual') {
    $where[] = 'l.import_id IS NULL';
} elseif ($filterImport !== '' && ctype_digit($filterImport)) {
    $where[] = 'l.import_id = ?';
    $types .= 'i';
    $params[] = (int) $filterImport;
}

if ($filterStatus !== '' && array_key_exists($filterStatus, lead_statuses())) {
    $where[] = 'l.status = ?';
    $types .= 's';
    $params[] = $filterStatus;
}
if ($filterCategory !== '') {
    $where[] = 'l.category = ?';
    $types .= 's';
    $params[] = $filterCategory;
}
if ($filterCity !== '') {
    $where[] = 'l.city = ?';
    $types .= 's';
    $params[] = $filterCity;
}
if ($filterExecutive === '0' || $filterExecutive === 'unassigned') {
    $where[] = 'l.assigned_to IS NULL';
} elseif ($filterExecutive !== '' && ctype_digit($filterExecutive)) {
    $where[] = 'l.assigned_to = ?';
    $types .= 'i';
    $params[] = (int) $filterExecutive;
}

if ($search !== '') {
    $where[] = '(l.business_name LIKE ? OR l.phone LIKE ? OR l.email LIKE ? OR l.address LIKE ?
                OR l.contact_name LIKE ? OR l.alternate_phone LIKE ?
                OR li.original_filename LIKE ? OR li.filename LIKE ?)';
    $like = '%' . $search . '%';
    $types .= 'ssssssss';
    array_push($params, $like, $like, $like, $like, $like, $like, $like, $like);
}

$whereSql = implode(' AND ', $where);

$totalRow = $conn->query('SELECT COUNT(*) AS c FROM leads WHERE is_deleted = 0')->fetch_assoc();
$recordsTotal = (int) ($totalRow['c'] ?? 0);

$countSql = "SELECT COUNT(*) AS c
             FROM leads l
             LEFT JOIN users u ON u.id = l.assigned_to
             LEFT JOIN lead_imports li ON li.id = l.import_id
             WHERE {$whereSql}";
$countStmt = $conn->prepare($countSql);
if ($types !== '') {
    $countStmt->bind_param($types, ...$params);
}
$countStmt->execute();
$recordsFiltered = (int) ($countStmt->get_result()->fetch_assoc()['c'] ?? 0);

$dataSql = "SELECT l.id, l.business_name, l.contact_name, l.phone, l.email, l.city, l.category,
                   l.status, l.priority, l.address, l.created_at, l.assigned_to, l.import_id,
                   u.name AS executive_name,
                   li.original_filename, li.filename AS import_filename
            FROM leads l
            LEFT JOIN users u ON u.id = l.assigned_to
            LEFT JOIN lead_imports li ON li.id = l.import_id
            WHERE {$whereSql}
            ORDER BY {$orderBy} {$orderDir}
            LIMIT ?, ?";

$dataTypes = $types . 'ii';
$dataParams = $params;
$dataParams[] = $start;
$dataParams[] = $length;

$dataStmt = $conn->prepare($dataSql);
$dataStmt->bind_param($dataTypes, ...$dataParams);
$dataStmt->execute();
$result = $dataStmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $id = (int) $row['id'];
    $actions = '<div class="btn-group btn-group-sm">'
        . '<a href="lead_view.php?id=' . $id . '&call=1" class="btn btn-success" title="Call"><i class="fas fa-phone"></i></a>'
        . '<a href="lead_view.php?id=' . $id . '" class="btn btn-info" title="View"><i class="fas fa-eye"></i></a>'
        . '<a href="lead_edit.php?id=' . $id . '" class="btn btn-primary" title="Edit"><i class="fas fa-edit"></i></a>'
        . '<button type="button" class="btn btn-danger btn-delete-lead" data-id="' . $id . '" title="Delete"><i class="fas fa-trash"></i></button>'
        . '</div>';

    $fileName = $row['original_filename'] ?: ($row['import_filename'] ?: '');
    if ($fileName !== '' && !empty($row['import_id'])) {
        $excelFile = '<a class="import-file-chip" href="leads.php?import_id=' . (int) $row['import_id'] . '" title="Show leads from this file">'
            . htmlspecialchars($fileName) . '</a>';
    } else {
        $excelFile = '<span class="text-muted">Manual</span>';
    }

    $data[] = [
        'id' => $id,
        'checkbox' => '<input type="checkbox" class="lead-check" value="' . $id . '">',
        'business_name' => htmlspecialchars($row['business_name'] ?: '—'),
        'phone' => htmlspecialchars($row['phone'] ?: '—'),
        'email' => htmlspecialchars($row['email'] ?: '—'),
        'city' => htmlspecialchars($row['city'] ?: '—'),
        'category' => htmlspecialchars($row['category'] ?: '—'),
        'status' => lead_status_badge($row['status']),
        'excel_file' => $excelFile,
        'executive' => htmlspecialchars($row['executive_name'] ?: 'Unassigned'),
        'created_at' => htmlspecialchars($row['created_at']),
        'actions' => $actions,
    ];
}

echo json_encode([
    'draw' => $draw,
    'recordsTotal' => $recordsTotal,
    'recordsFiltered' => $recordsFiltered,
    'data' => $data,
]);
