-- =============================================================================
-- Calling CRM — Database Schema
-- Engine: InnoDB | Charset: utf8mb4
-- No seed data — import structure only
-- =============================================================================

CREATE DATABASE IF NOT EXISTS `calling_crm`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `calling_crm`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Drop in dependency order (children first)
DROP TABLE IF EXISTS `activities`;
DROP TABLE IF EXISTS `lead_status_history`;
DROP TABLE IF EXISTS `followups`;
DROP TABLE IF EXISTS `call_logs`;
DROP TABLE IF EXISTS `lead_assignments`;
DROP TABLE IF EXISTS `leads`;
DROP TABLE IF EXISTS `lead_imports`;
DROP TABLE IF EXISTS `settings`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `admin`; -- legacy shell table (removed)

-- =============================================================================
-- 1. users
-- CRM operators: admin, manager, agent
-- =============================================================================
CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(120) NOT NULL,
  `username` VARCHAR(80) NOT NULL,
  `email` VARCHAR(150) NULL DEFAULT NULL,
  `password` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(30) NOT NULL DEFAULT '',
  `role` ENUM('admin', 'manager', 'agent') NOT NULL DEFAULT 'agent',
  `status` ENUM('active', 'inactive', 'suspended') NOT NULL DEFAULT 'active',
  `last_login_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_username` (`username`),
  UNIQUE KEY `uk_users_email` (`email`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- 2. lead_imports
-- Tracks each CSV/Google-data import batch
-- =============================================================================
CREATE TABLE `lead_imports` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `imported_by` INT UNSIGNED NULL DEFAULT NULL,
  `filename` VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'Display / stored name',
  `original_filename` VARCHAR(255) NOT NULL DEFAULT '',
  `stored_filename` VARCHAR(255) NOT NULL DEFAULT '',
  `file_hash` CHAR(64) NULL DEFAULT NULL COMMENT 'SHA-256 for duplicate detection',
  `file_size` INT UNSIGNED NOT NULL DEFAULT 0,
  `source` VARCHAR(100) NOT NULL DEFAULT 'excel' COMMENT 'excel, google, csv, manual, api, other',
  `total_rows` INT UNSIGNED NOT NULL DEFAULT 0,
  `success_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `failed_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `duplicate_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('pending', 'processing', 'completed', 'failed', 'cancelled') NOT NULL DEFAULT 'pending',
  `error_log` TEXT NULL,
  `notes` TEXT NULL,
  `remarks` TEXT NULL,
  `started_at` DATETIME NULL DEFAULT NULL,
  `completed_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_lead_imports_file_hash` (`file_hash`),
  KEY `idx_lead_imports_status` (`status`),
  KEY `idx_lead_imports_source` (`source`),
  KEY `idx_lead_imports_created` (`created_at`),
  KEY `idx_lead_imports_imported_by` (`imported_by`),
  KEY `idx_lead_imports_original_filename` (`original_filename`),
  CONSTRAINT `fk_lead_imports_user`
    FOREIGN KEY (`imported_by`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- 3. leads
-- Core lead / business contact records
-- =============================================================================
CREATE TABLE `leads` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `import_id` INT UNSIGNED NULL DEFAULT NULL,
  `created_by` INT UNSIGNED NULL DEFAULT NULL,
  `assigned_to` INT UNSIGNED NULL DEFAULT NULL COMMENT 'Current assignee (denormalized for fast filters)',
  `business_name` VARCHAR(255) NOT NULL DEFAULT '',
  `contact_name` VARCHAR(150) NOT NULL DEFAULT '',
  `phone` VARCHAR(30) NOT NULL DEFAULT '',
  `alternate_phone` VARCHAR(30) NOT NULL DEFAULT '',
  `email` VARCHAR(150) NOT NULL DEFAULT '',
  `website` VARCHAR(255) NOT NULL DEFAULT '',
  `address` VARCHAR(500) NOT NULL DEFAULT '',
  `city` VARCHAR(100) NOT NULL DEFAULT '',
  `state` VARCHAR(100) NOT NULL DEFAULT '',
  `country` VARCHAR(100) NOT NULL DEFAULT '',
  `pincode` VARCHAR(20) NOT NULL DEFAULT '',
  `category` VARCHAR(150) NOT NULL DEFAULT '',
  `source` VARCHAR(100) NOT NULL DEFAULT 'google',
  `google_place_id` VARCHAR(191) NOT NULL DEFAULT '',
  `latitude` DECIMAL(10,7) NULL DEFAULT NULL,
  `longitude` DECIMAL(10,7) NULL DEFAULT NULL,
  `maps_url` VARCHAR(500) NOT NULL DEFAULT '',
  `rating` DECIMAL(3,2) NULL DEFAULT NULL,
  `review_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM(
    'new',
    'not_contacted',
    'attempted',
    'connected',
    'interested',
    'callback',
    'follow_up_required',
    'proposal_sent',
    'converted',
    'wrong_number',
    'duplicate',
    'not_interested',
    'closed'
  ) NOT NULL DEFAULT 'new',
  `priority` ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
  `notes` TEXT NULL,
  `remarks` TEXT NULL,
  `extra_data` JSON NULL COMMENT 'Unknown Excel columns preserved as JSON',
  `last_called_at` DATETIME NULL DEFAULT NULL,
  `next_followup_at` DATETIME NULL DEFAULT NULL,
  `is_deleted` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_leads_status` (`status`),
  KEY `idx_leads_priority` (`priority`),
  KEY `idx_leads_phone` (`phone`),
  KEY `idx_leads_email` (`email`),
  KEY `idx_leads_city` (`city`),
  KEY `idx_leads_category` (`category`),
  KEY `idx_leads_source` (`source`),
  KEY `idx_leads_business_name` (`business_name`),
  KEY `idx_leads_assigned_to` (`assigned_to`),
  KEY `idx_leads_import_id` (`import_id`),
  KEY `idx_leads_created_by` (`created_by`),
  KEY `idx_leads_next_followup` (`next_followup_at`),
  KEY `idx_leads_last_called` (`last_called_at`),
  KEY `idx_leads_deleted_status` (`is_deleted`, `status`),
  KEY `idx_leads_google_place` (`google_place_id`),
  CONSTRAINT `fk_leads_import`
    FOREIGN KEY (`import_id`) REFERENCES `lead_imports` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_leads_created_by`
    FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_leads_assigned_to`
    FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- 4. lead_assignments
-- Assignment history (who owned the lead over time)
-- =============================================================================
CREATE TABLE `lead_assignments` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `lead_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL COMMENT 'Assignee',
  `assigned_by` INT UNSIGNED NULL DEFAULT NULL,
  `is_active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  `assigned_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unassigned_at` DATETIME NULL DEFAULT NULL,
  `notes` VARCHAR(500) NOT NULL DEFAULT '',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lead_assignments_lead` (`lead_id`),
  KEY `idx_lead_assignments_user` (`user_id`),
  KEY `idx_lead_assignments_active` (`is_active`),
  KEY `idx_lead_assignments_lead_active` (`lead_id`, `is_active`),
  KEY `idx_lead_assignments_assigned_by` (`assigned_by`),
  CONSTRAINT `fk_lead_assignments_lead`
    FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lead_assignments_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lead_assignments_assigned_by`
    FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- 5. call_logs
-- Every outbound/inbound call attempt
-- =============================================================================
CREATE TABLE `call_logs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `lead_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL COMMENT 'Agent who made/received the call',
  `phone_dialed` VARCHAR(30) NOT NULL DEFAULT '',
  `call_type` ENUM('outbound', 'inbound') NOT NULL DEFAULT 'outbound',
  `call_status` ENUM(
    'connected',
    'no_answer',
    'busy',
    'wrong_number',
    'switched_off',
    'voicemail',
    'failed'
  ) NOT NULL DEFAULT 'no_answer',
  `outcome` ENUM(
    'interested',
    'not_interested',
    'callback',
    'converted',
    'invalid',
    'dnc',
    'no_response',
    'other'
  ) NULL DEFAULT NULL,
  `duration_seconds` INT UNSIGNED NOT NULL DEFAULT 0,
  `notes` TEXT NULL,
  `remarks` TEXT NULL,
  `next_followup_at` DATETIME NULL DEFAULT NULL,
  `lead_status_after` VARCHAR(50) NOT NULL DEFAULT '',
  `called_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_call_logs_lead` (`lead_id`),
  KEY `idx_call_logs_user` (`user_id`),
  KEY `idx_call_logs_called_at` (`called_at`),
  KEY `idx_call_logs_status` (`call_status`),
  KEY `idx_call_logs_outcome` (`outcome`),
  KEY `idx_call_logs_user_called` (`user_id`, `called_at`),
  CONSTRAINT `fk_call_logs_lead`
    FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_call_logs_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- 6. followups
-- Scheduled callbacks / follow-up tasks
-- =============================================================================
CREATE TABLE `followups` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `lead_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL COMMENT 'Agent responsible',
  `created_by` INT UNSIGNED NULL DEFAULT NULL,
  `scheduled_at` DATETIME NOT NULL,
  `completed_at` DATETIME NULL DEFAULT NULL,
  `status` ENUM('pending', 'completed', 'cancelled', 'missed', 'rescheduled') NOT NULL DEFAULT 'pending',
  `priority` ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
  `notes` TEXT NULL,
  `reminder_sent` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_followups_lead` (`lead_id`),
  KEY `idx_followups_user` (`user_id`),
  KEY `idx_followups_status` (`status`),
  KEY `idx_followups_scheduled` (`scheduled_at`),
  KEY `idx_followups_user_status_sched` (`user_id`, `status`, `scheduled_at`),
  KEY `idx_followups_created_by` (`created_by`),
  CONSTRAINT `fk_followups_lead`
    FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_followups_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_followups_created_by`
    FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- 7. lead_status_history
-- Audit trail for lead status changes
-- =============================================================================
CREATE TABLE `lead_status_history` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `lead_id` INT UNSIGNED NOT NULL,
  `changed_by` INT UNSIGNED NULL DEFAULT NULL,
  `old_status` VARCHAR(50) NOT NULL DEFAULT '',
  `new_status` VARCHAR(50) NOT NULL,
  `notes` VARCHAR(500) NOT NULL DEFAULT '',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lead_status_history_lead` (`lead_id`),
  KEY `idx_lead_status_history_changed_by` (`changed_by`),
  KEY `idx_lead_status_history_created` (`created_at`),
  KEY `idx_lead_status_history_new` (`new_status`),
  CONSTRAINT `fk_lead_status_history_lead`
    FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lead_status_history_user`
    FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- 8. activities
-- Generic activity feed (calls, notes, imports, assignments, etc.)
-- =============================================================================
CREATE TABLE `activities` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NULL DEFAULT NULL,
  `lead_id` INT UNSIGNED NULL DEFAULT NULL,
  `activity_type` VARCHAR(50) NOT NULL COMMENT 'login, call, note, assignment, import, status_change, followup, other',
  `title` VARCHAR(255) NOT NULL DEFAULT '',
  `description` TEXT NULL,
  `meta` JSON NULL COMMENT 'Optional structured payload',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_activities_user` (`user_id`),
  KEY `idx_activities_lead` (`lead_id`),
  KEY `idx_activities_type` (`activity_type`),
  KEY `idx_activities_created` (`created_at`),
  KEY `idx_activities_lead_created` (`lead_id`, `created_at`),
  CONSTRAINT `fk_activities_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_activities_lead`
    FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- 9. settings
-- Key/value application configuration
-- =============================================================================
CREATE TABLE `settings` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(100) NOT NULL,
  `setting_value` TEXT NULL,
  `setting_group` VARCHAR(50) NOT NULL DEFAULT 'general',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_settings_key` (`setting_key`),
  KEY `idx_settings_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_group`) VALUES
  ('nature_fx_enabled', '1', 'nature_fx'),
  ('nature_fx_frequency', 'medium', 'nature_fx'),
  ('nature_fx_types', 'all', 'nature_fx')
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);

SET FOREIGN_KEY_CHECKS = 1;
