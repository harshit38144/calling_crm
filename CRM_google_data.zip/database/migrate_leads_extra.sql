-- Add geo + extra_data columns for Excel lead import (existing DBs)
USE calling_crm;

ALTER TABLE leads
  ADD COLUMN latitude DECIMAL(10,7) NULL DEFAULT NULL AFTER google_place_id,
  ADD COLUMN longitude DECIMAL(10,7) NULL DEFAULT NULL AFTER latitude,
  ADD COLUMN maps_url VARCHAR(500) NOT NULL DEFAULT '' AFTER longitude,
  ADD COLUMN extra_data JSON NULL AFTER notes,
  ADD KEY idx_leads_business_name (business_name);
