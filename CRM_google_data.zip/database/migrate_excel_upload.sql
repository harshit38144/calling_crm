﻿-- Excel import columns for lead_imports (run if upgrading from older schema)
USE calling_crm;

ALTER TABLE lead_imports
  ADD COLUMN IF NOT EXISTS original_filename VARCHAR(255) NOT NULL DEFAULT '' AFTER filename,
  ADD COLUMN IF NOT EXISTS stored_filename VARCHAR(255) NOT NULL DEFAULT '' AFTER original_filename,
  ADD COLUMN IF NOT EXISTS file_hash CHAR(64) NULL DEFAULT NULL AFTER stored_filename,
  ADD COLUMN IF NOT EXISTS file_size INT UNSIGNED NOT NULL DEFAULT 0 AFTER file_hash,
  ADD COLUMN IF NOT EXISTS remarks TEXT NULL AFTER notes;

-- Note: MySQL < 8.0.12 may not support IF NOT EXISTS on ADD COLUMN.
-- Prefer re-importing database/schema.sql on fresh installs.
