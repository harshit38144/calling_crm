-- Ambient nature animation settings (Calling CRM)
-- Run once: mysql -u root calling_crm < database/migrate_nature_fx.sql

INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_group`) VALUES
  ('nature_fx_enabled', '1', 'nature_fx'),
  ('nature_fx_frequency', 'medium', 'nature_fx'),
  ('nature_fx_types', 'all', 'nature_fx')
ON DUPLICATE KEY UPDATE
  `setting_value` = VALUES(`setting_value`),
  `setting_group` = VALUES(`setting_group`);
