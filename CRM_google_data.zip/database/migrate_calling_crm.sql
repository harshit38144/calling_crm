-- Calling CRM: new lead statuses + call fields
USE calling_crm;

ALTER TABLE leads MODIFY COLUMN status VARCHAR(50) NOT NULL DEFAULT 'new';

UPDATE leads SET status = 'not_contacted' WHERE status = 'assigned';
UPDATE leads SET status = 'attempted' WHERE status = 'contacted';
UPDATE leads SET status = 'follow_up_required' WHERE status = 'follow_up';
UPDATE leads SET status = 'wrong_number' WHERE status = 'invalid';
UPDATE leads SET status = 'closed' WHERE status = 'dnc';

ALTER TABLE leads
  MODIFY COLUMN status ENUM(
    'new','not_contacted','attempted','connected','interested','callback',
    'follow_up_required','proposal_sent','converted','wrong_number',
    'duplicate','not_interested','closed'
  ) NOT NULL DEFAULT 'new';

ALTER TABLE leads ADD COLUMN remarks TEXT NULL AFTER notes;

ALTER TABLE call_logs
  ADD COLUMN remarks TEXT NULL AFTER notes,
  ADD COLUMN next_followup_at DATETIME NULL AFTER remarks,
  ADD COLUMN lead_status_after VARCHAR(50) NOT NULL DEFAULT '' AFTER next_followup_at;
