<?php
if (isset($_SERVER['HTTP_HOST']) && ($_SERVER['HTTP_HOST'] == 'localhost:8081' || $_SERVER['HTTP_HOST'] == 'localhost')) {
    $conn = new mysqli('localhost', 'root', '', 'calling_crm');
} else {
    // Update these credentials for production hosting
    $conn = new mysqli('localhost', 'root', '', 'calling_crm');
}

if ($conn->connect_errno) {
    die('Database connection failed. Please import database/schema.sql first.');
}

$conn->set_charset('utf8mb4');
date_default_timezone_set('Asia/Kolkata');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function require_login()
{
    if (empty($_SESSION['id'])) {
        header('Location: index.php');
        exit;
    }
}

function require_admin()
{
    require_login();
    $role = $_SESSION['role'] ?? '';
    // Allow admin/manager/agent (and legacy numeric role "1")
    $allowed = ['admin', 'manager', 'agent', '1'];
    if (!in_array((string) $role, $allowed, true)) {
        header('Location: index.php');
        exit;
    }
}

function flash_msg()
{
    if (!empty($_SESSION['msg'])) {
        $msg = $_SESSION['msg'];
        unset($_SESSION['msg']);
        return $msg;
    }
    return '';
}

function flash_type()
{
    if (!empty($_SESSION['msg_type'])) {
        $type = $_SESSION['msg_type'];
        unset($_SESSION['msg_type']);
        return $type;
    }
    return 'success';
}

/** Max Excel upload size in bytes (10 MB). */
function excel_max_upload_bytes()
{
    return 10 * 1024 * 1024;
}

function excel_allowed_extensions()
{
    return ['xls', 'xlsx'];
}

function lead_statuses(): array
{
    return [
        'new' => 'New',
        'not_contacted' => 'Not Contacted',
        'attempted' => 'Attempted',
        'connected' => 'Connected',
        'interested' => 'Interested',
        'callback' => 'Callback',
        'follow_up_required' => 'Follow-up Required',
        'proposal_sent' => 'Proposal Sent',
        'converted' => 'Converted',
        'wrong_number' => 'Wrong Number',
        'duplicate' => 'Duplicate',
        'not_interested' => 'Not Interested',
        'closed' => 'Closed',
    ];
}

function lead_priorities(): array
{
    return [
        'low' => 'Low',
        'medium' => 'Medium',
        'high' => 'High',
        'urgent' => 'Urgent',
    ];
}

function lead_status_badge(string $status): string
{
    $map = [
        'new' => 'secondary',
        'not_contacted' => 'light',
        'attempted' => 'info',
        'connected' => 'primary',
        'interested' => 'success',
        'callback' => 'warning',
        'follow_up_required' => 'warning',
        'proposal_sent' => 'info',
        'converted' => 'success',
        'wrong_number' => 'danger',
        'duplicate' => 'dark',
        'not_interested' => 'dark',
        'closed' => 'secondary',
    ];
    $labels = lead_statuses();
    $cls = $map[$status] ?? 'secondary';
    $label = $labels[$status] ?? ucfirst(str_replace('_', ' ', $status));
    return '<span class="badge badge-' . $cls . '">' . htmlspecialchars($label) . '</span>';
}

function call_result_statuses(): array
{
    return [
        'connected' => 'Connected',
        'no_answer' => 'No Answer',
        'busy' => 'Busy',
        'wrong_number' => 'Wrong Number',
        'switched_off' => 'Switched Off',
        'voicemail' => 'Voicemail',
        'failed' => 'Failed',
    ];
}

function set_flash(string $msg, string $type = 'success'): void
{
    $_SESSION['msg'] = $msg;
    $_SESSION['msg_type'] = $type;
}

function json_response(array $payload, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload);
    exit;
}

/**
 * Read a single setting value (with optional default).
 */
function get_setting(string $key, $default = null)
{
    global $conn;
    static $cache = [];

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    $stmt = $conn->prepare('SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1');
    if (!$stmt) {
        return $default;
    }
    $stmt->bind_param('s', $key);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res ? $res->fetch_assoc() : null;
    $stmt->close();

    $cache[$key] = $row ? $row['setting_value'] : $default;
    return $cache[$key];
}

/**
 * Upsert a setting value.
 */
function set_setting(string $key, string $value, string $group = 'general'): bool
{
    global $conn;
    $stmt = $conn->prepare(
        'INSERT INTO settings (setting_key, setting_value, setting_group)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), setting_group = VALUES(setting_group)'
    );
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('sss', $key, $value, $group);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

/** Allowed nature animation type keys. */
function nature_fx_type_options(): array
{
    return [
        'butterflies' => 'Butterflies',
        'fireflies' => 'Fireflies',
        'leaves' => 'Leaves',
        'feathers' => 'Feathers',
        'birds' => 'Birds',
        'insects' => 'Insects (ladybugs & dragonflies)',
    ];
}

/**
 * Resolved config for the ambient nature FX engine (safe defaults).
 */
function nature_fx_config(): array
{
    static $cfg = null;
    if ($cfg !== null) {
        return $cfg;
    }

    $enabled = get_setting('nature_fx_enabled', '1') === '1';
    $freq = get_setting('nature_fx_frequency', 'medium');
    if (!in_array($freq, ['low', 'medium', 'high'], true)) {
        $freq = 'medium';
    }

    $typesRaw = (string) get_setting('nature_fx_types', 'all');
    $allowed = array_keys(nature_fx_type_options());
    if ($typesRaw === 'all' || $typesRaw === '') {
        $types = $allowed;
    } else {
        $picked = array_values(array_filter(array_map('trim', explode(',', $typesRaw))));
        $types = array_values(array_intersect($picked, $allowed));
        if (empty($types)) {
            $types = $allowed;
        }
    }

    $cfg = [
        'enabled' => $enabled,
        'frequency' => $freq,
        'types' => $types,
    ];
    return $cfg;
}
