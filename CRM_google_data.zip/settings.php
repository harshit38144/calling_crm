<?php
include_once 'connection.php';
require_admin();

$typeOptions = nature_fx_type_options();
$cfg = nature_fx_config();

$enabled = get_setting('nature_fx_enabled', '1') === '1';
$frequency = get_setting('nature_fx_frequency', 'medium');
$typesRaw = (string) get_setting('nature_fx_types', 'all');
$selectedTypes = ($typesRaw === 'all' || $typesRaw === '')
    ? array_keys($typeOptions)
    : array_values(array_filter(array_map('trim', explode(',', $typesRaw))));

$msg = flash_msg();
$msgType = flash_type();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Settings | Calling CRM</title>
  <?php include 'includes/header-links.php'; ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
  <?php include 'includes/top-header.php'; ?>
  <?php include 'includes/sidebar.php'; ?>
  <div class="content-wrapper">
    <?php include 'includes/page-header.php'; ?>
    <section class="content">
      <div class="container-fluid">

        <?php if ($msg): ?>
          <div class="alert alert-<?= htmlspecialchars($msgType === 'error' ? 'danger' : $msgType) ?>">
            <?= htmlspecialchars($msg) ?>
          </div>
        <?php endif; ?>

        <div class="row">
          <div class="col-lg-8">
            <div class="card card-outline card-primary">
              <div class="card-header">
                <h3 class="card-title mb-0"><i class="fas fa-leaf mr-2"></i>Ambient Nature Animations</h3>
              </div>
              <div class="card-body">
                <p class="text-muted mb-4">
                  Subtle butterflies, fireflies, leaves, and birds drift across the admin panel occasionally.
                  They never block clicks and stay low-opacity so work stays uninterrupted.
                </p>

                <form method="post" action="sql/settings_save.php" id="natureFxForm">
                  <input type="hidden" name="save_nature_fx" value="1">

                  <div class="form-group">
                    <div class="custom-control custom-switch">
                      <input type="checkbox" class="custom-control-input" id="nature_fx_enabled"
                             name="nature_fx_enabled" value="1" <?= $enabled ? 'checked' : '' ?>>
                      <label class="custom-control-label" for="nature_fx_enabled">
                        Enable nature animations
                      </label>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="nature_fx_frequency">Animation frequency</label>
                    <select name="nature_fx_frequency" id="nature_fx_frequency" class="custom-select" style="max-width:280px;">
                      <option value="low" <?= $frequency === 'low' ? 'selected' : '' ?>>Low — every ~1–2 minutes</option>
                      <option value="medium" <?= $frequency === 'medium' ? 'selected' : '' ?>>Medium — every ~30–90 seconds</option>
                      <option value="high" <?= $frequency === 'high' ? 'selected' : '' ?>>High — every ~15–45 seconds</option>
                    </select>
                    <small class="form-text text-muted">Only one or two animations appear at a time.</small>
                  </div>

                  <div class="form-group">
                    <label class="d-block mb-2">Animation types</label>
                    <div class="custom-control custom-checkbox mb-2">
                      <input type="checkbox" class="custom-control-input" id="types_all"
                             <?= ($typesRaw === 'all' || count($selectedTypes) === count($typeOptions)) ? 'checked' : '' ?>>
                      <label class="custom-control-label" for="types_all"><strong>All types</strong></label>
                    </div>
                    <div class="pl-1" id="typeChecks">
                      <?php foreach ($typeOptions as $key => $label): ?>
                        <div class="custom-control custom-checkbox mb-1">
                          <input type="checkbox" class="custom-control-input nature-type"
                                 id="type_<?= htmlspecialchars($key) ?>"
                                 name="nature_fx_types[]"
                                 value="<?= htmlspecialchars($key) ?>"
                                 <?= in_array($key, $selectedTypes, true) ? 'checked' : '' ?>>
                          <label class="custom-control-label" for="type_<?= htmlspecialchars($key) ?>">
                            <?= htmlspecialchars($label) ?>
                          </label>
                        </div>
                      <?php endforeach; ?>
                    </div>
                  </div>

                  <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Save Settings
                  </button>
                  <button type="button" class="btn btn-outline-secondary ml-1" id="btnPreviewFx">
                    <i class="fas fa-play"></i> Preview once
                  </button>
                </form>
              </div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title mb-0"><i class="fas fa-info-circle mr-2"></i>How it works</h3>
              </div>
              <div class="card-body">
                <ul class="mb-0 pl-3 text-muted" style="font-size:0.92rem; line-height:1.7;">
                  <li>SVG-only — no image downloads</li>
                  <li><code>pointer-events: none</code> — never blocks UI</li>
                  <li>Respects <em>prefers-reduced-motion</em></li>
                  <li>Pauses when the browser tab is hidden</li>
                  <li>Applies on every admin page automatically</li>
                </ul>
                <hr>
                <p class="mb-1"><strong>Current</strong></p>
                <p class="mb-0 text-muted small">
                  <?= $cfg['enabled'] ? 'On' : 'Off' ?>
                  · <?= htmlspecialchars(ucfirst($cfg['frequency'])) ?>
                  · <?= count($cfg['types']) ?> type(s)
                </p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  </div>
  <?php include 'includes/copyright.php'; ?>
</div>
<?php include 'includes/footer-links.php'; ?>
<script>
(function () {
  var all = document.getElementById('types_all');
  var checks = document.querySelectorAll('.nature-type');

  function syncFromAll() {
    var on = all.checked;
    checks.forEach(function (c) { c.checked = on; });
  }
  function syncToAll() {
    var n = 0;
    checks.forEach(function (c) { if (c.checked) n++; });
    all.checked = n === checks.length;
  }

  all.addEventListener('change', syncFromAll);
  checks.forEach(function (c) { c.addEventListener('change', syncToAll); });

  document.getElementById('btnPreviewFx').addEventListener('click', function () {
    if (!window.CRMNatureFx) {
      // Temporarily load engine for preview when FX disabled
      var link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'custom/nature-fx.css?v=2';
      document.head.appendChild(link);
      window.CRM_NATURE_FX = {
        enabled: true,
        frequency: document.getElementById('nature_fx_frequency').value || 'medium',
        types: Array.prototype.map.call(
          document.querySelectorAll('.nature-type:checked'),
          function (c) { return c.value; }
        )
      };
      if (!window.CRM_NATURE_FX.types.length) {
        window.CRM_NATURE_FX.types = ['butterflies', 'leaves', 'fireflies', 'birds', 'feathers', 'insects'];
      }
      var s = document.createElement('script');
      s.src = 'custom/nature-fx.js?v=2';
      s.onload = function () {
        if (window.CRMNatureFx) {
          window.CRMNatureFx.init(window.CRM_NATURE_FX);
          window.CRMNatureFx.spawnBurst();
        }
      };
      document.body.appendChild(s);
      return;
    }
    window.CRMNatureFx.spawnBurst();
  });
})();
</script>
</body>
</html>
